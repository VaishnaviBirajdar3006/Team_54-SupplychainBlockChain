const StateContract = artifacts.require("StateContract");
const SupplyChain = artifacts.require("SupplyChain");

contract("SupplyChain", (accounts) => {
  it("should add a product and states", async () => {
    const stateContract = await StateContract.new();
    const supplyChain = await SupplyChain.new(stateContract.address);

    await supplyChain.newItem("Product A", "2023-08-07");

    await supplyChain.addState(0, "Manufacturing Complete");
    await supplyChain.addState(0, "Quality Check Passed");
    await supplyChain.addState(0, "Ready for Shipment");

    const stateCount = await supplyChain.getProductPositionCount(0);
    assert.equal(stateCount, 3, "State count does not match");
  });

  // Add more test cases...
});
