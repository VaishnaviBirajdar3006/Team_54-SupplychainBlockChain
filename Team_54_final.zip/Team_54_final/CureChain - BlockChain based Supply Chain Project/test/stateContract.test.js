const StateContract = artifacts.require("StateContract");

contract("StateContract", (accounts) => {
  it("should add a state", async () => {
    const stateContract = await StateContract.new();
    console.log("Added Successfully!!!!");
    await stateContract.addState(0, "Manufacturing Complete");
    const stateCount = await stateContract.getStateCount(0);

    assert.equal(stateCount, 1, "State count does not match");
  });

  // Add more test cases...
});
